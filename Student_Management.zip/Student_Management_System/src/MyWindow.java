import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class MyWindow implements ActionListener{
	private static Connection con;
	private static Statement stmt;
	
	JFrame f;
	JLabel title;
	JLabel roll_no;
	JTextField troll_no;
	JLabel name;
	JTextField tname;
	JLabel percentage;
	JTextField tpercentage;
	JTextArea tout;
	JLabel res;
	
	JButton add, update, delete, show;
	
	MyWindow()throws ClassNotFoundException{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Driver Loaded.");
		
		f = new JFrame("Student Management System");
		f.setLayout(null);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setBounds(300,90,900,600);
		f.setResizable(false);
		Font fo = new Font("Arial",Font.BOLD,20);
		
		title = new JLabel("Student Management System");
        title.setFont(new Font("Arial",Font.BOLD,30));
		title.setBounds(250,30,500,40);
		f.add(title);
		
		name = new JLabel("Name");
        name.setFont(new Font("Arial",Font.BOLD,20));
        name.setSize(100,20);
        name.setLocation(100,100);
        f.add(name);
        
        tname = new JTextField();
        tname.setFont(new Font("Arial",Font.BOLD,20));
        tname.setSize(150,20);
        tname.setLocation(230,100);
        f.add(tname);
    
        roll_no = new JLabel("Roll No.");
        roll_no.setFont(new Font("Arial", Font.BOLD, 20));
        roll_no.setSize(190, 20);
        roll_no.setLocation(100, 150);
        f.add(roll_no);

        troll_no = new JTextField();
        troll_no.setFont(new Font("Arial", Font.BOLD, 20));
        troll_no.setSize(150, 20);
        troll_no.setLocation(230, 150);
        f.add(troll_no);
        
        percentage = new JLabel("Percentage");
        percentage.setFont(new Font("Arial", Font.BOLD, 20));
        percentage.setSize(150, 20);
        percentage.setLocation(100, 200);
        f.add(percentage);

        tpercentage = new JTextField();
        tpercentage.setFont(new Font("Arial", Font.BOLD, 20));
        tpercentage.setSize(150, 20);
        tpercentage.setLocation(230, 200);
        f.add(tpercentage);
		
        
        add = new JButton("Add");
        add.setFont(new Font("Arial", Font.BOLD,20));
        add.setSize(100,20);
        add.setLocation(150,300);
        add.addActionListener(this);
        f.add(add);
        
        update = new JButton("Update");
        update.setFont(new Font("Arial", Font.BOLD,20));
        update.setSize(105,20);
        update.setLocation(275,300);
        update.addActionListener(this);
        f.add(update);
        
        delete = new JButton("Delete");
        delete.setFont(new Font("Arial", Font.BOLD,20));
        delete.setSize(100,20);
        delete.setLocation(150,350);
        delete.addActionListener(this);
        f.add(delete);
        
        show = new JButton("Show");
        show.setFont(new Font("Arial", Font.BOLD,20));
        show.setSize(100,20);
        show.setLocation(275,350);
        show.addActionListener(this);
        f.add(show);
        
        tout = new JTextArea();
        tout.setFont(new Font("Arial", Font.PLAIN,15));
        tout.setSize(300,400);
        tout.setLocation(500,100);
        tout.setLineWrap(false);
        f.add(tout);
        
        res = new JLabel("");
        res.setFont(new Font("Arial", Font.PLAIN,15));
        res.setSize(500,25);
        res.setLocation(100,400);
        f.add(res);
        
        
		f.setVisible(true);
		
	}
	
	
	

	public static void main(String[] args) throws Exception {
		MyWindow obj = new MyWindow();
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");
		System.out.println("Connection Successful");
		
		//obj.createTable();
		//insertPreparedStatement();
//		insertRecord();
	}




	
//	private void createTable() throws SQLException {
//		stmt = con.createStatement();
//		String createTable = "create table student(stud_rno int,stud_name varchar(30))";
//		boolean res = stmt.execute(createTable);
//		System.out.println("Table created...........");
	
		/*
		String createQuery = "create table student(roll_no int, name varchar(10),percentage int)";
		System.out.println("create Query"+ createQuery);
		boolean result = stmt.execute(createQuery);
		
		System.out.println(result);
		*/
//		String show = "select * from emp";
//		ResultSet rs = stmt.executeQuery(show);
//		rs.next();
//		System.out.println(rs.getInt(1));
//	}
	
	

//	private static void insertPreparedStatement() throws SQLException{
//		PreparedStatement pstmt = con.prepareStatement("insert into student values(?,?,?");
//		con.setAutoCommit(false);
//		pstmt.clearParameters();
//		pstmt.setInt(1, 1);
//		pstmt.setString(2, "Ajay");
//		pstmt.setInt(3, 89);
//		pstmt.executeUpdate();
//		con.commit();
//		System.out.println("Record inserted successfully");
//		
//	}
	
	public static void insertRecord() throws SQLException{
		stmt = con.createStatement();
		Scanner sc = new Scanner(System.in);
		int roll_no;
		String name;
		int percentage;
		
		System.out.println("Enter roll number.");
		roll_no = sc.nextInt();
		System.out.println("Enter Name.");
		name = sc.next();
		System.out.println("Enter percentage.");
		percentage = sc.nextInt();
		
		String insertQuery = "insert into student values("+roll_no+",'"+name+"',"+percentage+")";
		int ins_rec = stmt.executeUpdate(insertQuery);
		System.out.println("Inserted Successfully.........");
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			stmt = con.createStatement();
			
			if(e.getSource() == add) {
//				String roll_no = troll_no.getText();
//				String name = tname.getText();
//				String percentage = tpercentage.getText();
//				String query = "insert into student( roll_no, name, percentage)values("+roll_no+",'"+name+"',"+percentage+")";
//				stmt.executeUpdate(query);
				
				String data = "Name: "+ tname.getText() + "\n" + "roll_no: "+ troll_no.getText()+ "\n" + "percenatge: " + tpercentage.getText();
				tout.setText(data);
                tout.setEditable(false);
                res.setText("Inserted successfully..........");
				JOptionPane.showMessageDialog(null, "Record Added Successfully");
			}else if(e.getSource() == update){
				String roll_no = troll_no.getText();
				String name = tname.getText();
				String percentage = tpercentage.getText();
				String query = "update student set name= '"+name+"',percentage= "+percentage+" where roll_no= "+roll_no;

				
				stmt.executeUpdate(query);
				JOptionPane.showMessageDialog(null, "Record Updated Successfully");
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		
	}

}
